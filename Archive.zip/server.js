const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cors = require("cors");
const loginRoute = require("./routes/login_route");
const adminRoute = require('./routes/admin/admin_routes')
const configs = require('./config/config');
const constants = require("./utils/constants");
// const busboy = require('connect-busboy'); //middleware for form/file upload
// Middleware to parse URL-encoded data (for simple form submissions)
app.use(express.urlencoded({ extended: true }));
const path = require('path'); //used for file path
const fs = require('fs');
const router = express.Router();
const db = require("./config/mysqldb");
require('./config/dbCon');
const multer = require('multer');
// Middleware to parse JSON bodies
app.use(express.json());
app.use(cors());
app.use(bodyParser.json());


// app.use(busboy());
// Serve static files (images) from the "uploads" folder
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// Serve static files from the 'public/images' folder
//app.use('/uploads', express.static(path.join(__dirname, 'public/uploads')));
// app.use(express.static(path.join(__dirname, 'public')));

app.use("/api/", loginRoute);
app.use("/api/admin",adminRoute);


// Global error handler for multer
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    // Multer specific errors (e.g., file size limit exceeded)
    return res.status(400).json({ error: err.message });
  }

  // Handle other errors
  return res.status(500).json({ error: err.message });
});
const server = app.listen(configs.BACKEND_PORT, function () {
    console.log("Student management system backend server is running on port : " + configs.BACKEND_PORT);
});