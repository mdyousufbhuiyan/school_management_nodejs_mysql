const express = require("express");
const constants = require('../utils/constants');
const statusCode = require("../utils/status_code");
const db = require("../config/mysqldb");

exports.addTimeSlot = (req, res) => {
  console.log(`......name............${req.body.start_time}`);
  const sql = `SELECT * FROM ${constants.TIME_SLOT_TABLE} WHERE start_time = ? AND end_time = ?`;

  db.query(sql, [req.body.start_time,req.body.end_time], (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(statusCode.STATUS_BAD_REQUEST).json({
        message: "Failed",
        err,
      });
    }
    if (rows.length > 0) {
      console.log(rows);
      return res.status(statusCode.STATUS_CONFLICT).json({
        message: "Already Exists",
      });
    } else {
      db.query(
        `INSERT INTO ${constants.TIME_SLOT_TABLE} SET ?`,
        req.body,
        (err, rows, fields) => {
          if (err instanceof Error) {
            console.log(err);
            return res.status(statusCode.STATUS_BAD_REQUEST).json({
              message: "Failed",
              error: err,
            });
          } else {
            res.status(statusCode.STATUS_CREATED).json({
              message: "Success",
              data: rows,
            });
          }
        }
      );
    }
  });
};
exports.getTimeSlotById = (req, res) => {
  const sql = `SELECT * FROM ${constants.TIME_SLOT_TABLE} WHERE id = ?`;

  db.query(sql, [req.params.id], (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(statusCode.STATUS_BAD_REQUEST).json({
        message: "Failed",
        error: err,
      });
    }
    if (rows.length > 0) {
      res.status(statusCode.STATUS_OK).json({
        message: "Success",
        data: rows[0],
      });
    } else {
      res.status(statusCode.STATUS_NOT_FOUND).json({
        message: "Not Found",
      });
    }
  });
};

exports.getAllTimeSlot = (req, res) => {
  const sql = `SELECT * FROM ${constants.TIME_SLOT_TABLE}`;

  db.query(sql, (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(statusCode.STATUS_BAD_REQUEST).json({
        message: "Failed",
        error: err,
      });
    }
    res.status(statusCode.STATUS_OK).json({
      message: "Success",
      data: rows,
    });
  });
};
exports.getAllTimeSlotOnlyDropdown = (req, res) => {
  const sql = `SELECT id,start_time,end_time FROM ${constants.TIME_SLOT_TABLE}`;

  db.query(sql, (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(statusCode.STATUS_BAD_REQUEST).json({
        message: "Failed",
        error: err,
      });
    }
    res.status(statusCode.STATUS_OK).json({
      message: "Success",
      data: rows,
    });
  });
};
//update
exports.updateTimeSlot = (req, res) => {

  const sql = `SELECT * FROM ${constants.TIME_SLOT_TABLE} WHERE id != ? AND start_time = ? AND end_time = ?`;
  
  db.query(sql, [req.params.id, req.body.start_time, req.body.end_time], (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(statusCode.STATUS_BAD_REQUEST).json({
        message: "Failed",
        error: err,
      });
    }

    if (rows.length > 0) {
      console.log(rows);
      return res.status(statusCode.STATUS_CONFLICT).json({
        message: "Already Exists",
      });
    } else {
      // Construct the final UPDATE query string
      const query = `UPDATE ${constants.TIME_SLOT_TABLE} SET start_time = ?,end_time = ? WHERE id = ?`;

      // Execute the query
      db.query(query, [req.body.start_time,req.body.end_time, req.params.id], (err, result) => {
        if (err) {
          return res.status(statusCode.STATUS_BAD_REQUEST).json({ 
            message: "Failed",
            error: err });
        }

        // Check if any row was updated
        if (result.affectedRows === 0) {
          return res.status(statusCode.STATUS_NOT_FOUND).json({ message: "Not found" });
        }

        // Return a success response
        res.status(statusCode.STATUS_OK).json({
          message: "Subject updated successfully",
          data: result.affectedRows,
        });
      });
    }
  });
};

//delete
exports.deleteTimeSlot = (req, res) => {
  
  const id = req.params.id; // Get the ID from the request parameters

  // SQL query to delete the record from the database
  const sql = `DELETE FROM ${constants.TIME_SLOT_TABLE} WHERE id = ?`;

  // Execute the SQL query
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error('Error deleting User:', err);
      return res.status(statusCode.STATUS_BAD_REQUEST).json({ message: 'Failed to delete item', error: err });
    }

    if (result.affectedRows === 0) {
      return res.status(statusCode.STATUS_NOT_FOUND).json({ message: 'Not found' });
    }

    // If the record is deleted successfully
    return res.status(statusCode.STATUS_OK).json({ message: 'Deleted successfully' });
  });
};


