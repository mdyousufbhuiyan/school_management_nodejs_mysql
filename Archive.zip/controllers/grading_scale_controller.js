const express = require("express");
const configs = require("../config/config.json");
const constants = require("../utils/constants");
const statusCode = require("../utils/status_code");
const db = require("../config/mysqldb");
var tName = constants.GRADING_TABLE_NAME;
exports.addGrading = (req, res) => {
  console.log(`......name............${req.body.name}`);
  const sql = `SELECT * FROM ${tName} WHERE minimum_percent = ? AND maximum_percent = ?`;

  db.query(
    sql,
    [req.body.minimum_percent, req.body.maximum_percent],
    (err, rows, fields) => {
      if (err instanceof Error) {
        console.log(err);
        return res.status(statusCode.STATUS_BAD_REQUEST).json({
          message: "Failed",
          err,
        });
      }
      if (rows.length > 0) {
        console.log(rows);
        return res.status(statusCode.STATUS_CONFLICT).json({
          message: "Already Exists",
        });
      } else {
        db.query(
          `INSERT INTO ${tName} SET ?`,
          req.body,
          (err, rows, fields) => {
            if (err instanceof Error) {
              console.log(err);
              return res.status(statusCode.STATUS_BAD_REQUEST).json({
                message: "Failed",
                error: err,
              });
            } else {
              res.status(statusCode.STATUS_CREATED).json({
                message: "Success",
                data: rows,
              });
            }
          }
        );
      }
    }
  );
};

exports.getAllGrading = (req, res) => {
  const sql = `SELECT * FROM ${tName} ORDER BY grade_point DESC`;

  db.query(sql, (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(statusCode.STATUS_BAD_REQUEST).json({
        message: "Failed",
        error: err,
      });
    }
    res.status(statusCode.STATUS_OK).json({
      message: "Success",
      data: rows,
    });
  });
};

exports.getAllGradingForDropdown = (req, res) => {
  var sql;
  sql = `SELECT id,minimum_percent,maximum_percent,grade_name,grade_point FROM ${tName} ORDER BY grade_point DESC`;
  db.query(sql, (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(statusCode.STATUS_BAD_REQUEST).json({
        message: "Failed",
        error: err,
      });
    }
    res.status(statusCode.STATUS_OK).json({
      message: "Success",
      data: rows,
    });
  });
};

exports.getGradingById = (req, res) => {
  const sql = `SELECT * FROM ${tName} WHERE id = ?`;

  db.query(sql, [req.params.id], (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(statusCode.STATUS_BAD_REQUEST).json({
        message: "Failed",
        error: err,
      });
    }
    if (rows.length > 0) {
      res.status(statusCode.STATUS_OK).json({
        message: "Success",
        data: rows[0],
      });
    } else {
      res.status(statusCode.STATUS_NOT_FOUND).json({
        message: "Not Found",
      });
    }
  });
};
exports.updateGrading = (req, res) => {
  const sql = `SELECT * FROM ${tName} WHERE id != ? AND minimum_percent = ? AND maximum_percent = ?`;

  db.query(
    sql,
    [req.params.id, req.body.minimum_percent, req.body.maximum_percent],
    (err, rows, fields) => {
      if (err instanceof Error) {
        console.log(err);
        return res.status(statusCode.STATUS_BAD_REQUEST).json({
          message: "Failed",
          error: err,
        });
      }

      if (rows.length > 0) {
        console.log(rows);
        return res.status(statusCode.STATUS_CONFLICT).json({
          message: "Already Exists",
        });
      } else {
        const id = req.params.id; // Get the user id from the URL
        const updateData = req.body; // Get the fields to update from the request body

        // Dynamically build the SQL SET clause and the values array for the query
        let setClause = [];
        let values = [];

        // Loop through the keys of the object and build the SET part of the query
        for (let key in updateData) {
          if (
            key === "updated_at" ||
            key === "created_at"
            // ||
            // key === "academic_year_id" ||
            // key === "attendance_date"
          ) {
          } else {
            setClause.push(`${key} = ?`); // For each key in the object, add `key = ?`
            values.push(updateData[key]); // Push the value corresponding to the key
          }
        }
        // console.log(`.............setClause.......${setClause}..values....${values}`);
        // Add the user ID to the values array (for the WHERE clause)
        values.push(id);

        // Construct the final UPDATE query string
        const query = `UPDATE ${tName} SET ${setClause.join(
          ", "
        )} WHERE id = ?`;
        // Execute the query
        db.query(query, values, (err, result) => {
          if (err) {
            return res.status(statusCode.STATUS_BAD_REQUEST).json({
              message: "Failed",
              error: err,
            });
          }

          // Check if any row was updated
          if (result.affectedRows === 0) {
            return res
              .status(statusCode.STATUS_NOT_FOUND)
              .json({ message: "Not found" });
          }

          // Return a success response
          res.status(statusCode.STATUS_OK).json({
            message: "Updated successfully",
            data: result.affectedRows,
          });
        });
      }
    }
  );
};

//delete
exports.deleteGrading = (req, res) => {
  const id = req.params.id; // Get the ID from the request parameters

  // SQL query to delete the record from the database
  const sql = `DELETE FROM ${tName} WHERE id = ?`;

  // Execute the SQL query
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error("Error deleting User:", err);
      return res
        .status(statusCode.STATUS_BAD_REQUEST)
        .json({ message: "Failed to delete item", error: err });
    }

    if (result.affectedRows === 0) {
      return res
        .status(statusCode.STATUS_NOT_FOUND)
        .json({ message: "Not found" });
    }

    // If the record is deleted successfully
    return res
      .status(statusCode.STATUS_OK)
      .json({ message: "Deleted successfully" });
  });
};
