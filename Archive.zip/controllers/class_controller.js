const express = require("express");
const configs = require("../config/config.json");
const constants = require("../utils/constants");
const db = require("../config/mysqldb");

exports.addClasses = (req, res) => {
  console.log(`......name............${req.body.name}`);
  const sql = `SELECT * FROM ${constants.CLASS_NAME_TABLE} WHERE name = ? AND group_id = ?`;

  db.query(sql, [req.body.name,req.body.group_id], (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(401).json({
        message: "Failed",
        err,
      });
    }
    if (rows.length > 0) {
      console.log(rows);
      return res.status(401).json({
        message: "Already Exists",
      });
    } else {
      db.query(
        `INSERT INTO ${constants.CLASS_NAME_TABLE} SET ?`,
        req.body,
        (err, rows, fields) => {
          if (err instanceof Error) {
            console.log(err);
            return res.status(404).json({
              message: "Failed",
              error:err
            });
          } else if (rows) {
            res.status(201).json({
              message: "Success",
              data: rows,
            });
          } else {
            console.log(rows);
            return res.status(404).json({
              message: "Failed",
              data:rows
            });
          }
        }
      );
    }
  });
};
exports.getClassByClassId = (req, res) => {
 // const sql = `SELECT * FROM ${constants.CLASS_NAME_TABLE} WHERE id = ?`;
  const sql = `SELECT c.id,c.name,c.group_id,c.created_at,c.updated_at, JSON_OBJECT('id', g.id,'name', g.name,'name_bn', g.bn_name) AS group_info FROM ${constants.CLASS_NAME_TABLE} as c LEFT JOIN ${constants.GROUP_NAME_TABLE_NAME} as g ON c.group_id = g.id WHERE c.id = ?`;

  db.query(sql, [req.params.id], (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(401).json({
        message: "Failed",
        err,
      });
    }
    if (rows.length > 0) {
      res.status(201).json({
        message: "Success",
        data: parseRelationalDataToJson(rows)[0],
      });
    }else{
      res.status(201).json({
        message: "Not Found",
      });
    }
  });
};

exports.getAllClasses = (req, res) => {
  const sql = `SELECT c.id,c.name,c.group_id,c.created_at,c.updated_at, JSON_OBJECT('id', g.id,'name', g.name,'name_bn', g.bn_name) AS group_info FROM ${constants.CLASS_NAME_TABLE} as c LEFT JOIN ${constants.GROUP_NAME_TABLE_NAME} as g ON c.group_id = g.id`;

  db.query(sql, (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(401).json({
        message: "Failed",
        err,
      });
    }
    res.status(201).json({
      message: "Success",
      data: parseRelationalDataToJson(rows),
    });
  });
};

exports.getAllClassesForDropdown = (req, res) => {
  const sql = `SELECT * FROM ${constants.CLASS_NAME_TABLE}`;

  db.query(sql, (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(401).json({
        message: "Failed",
        err,
      });
    }
    res.status(201).json({
      data: rows,
    });
  });
};

exports.updateClasses = (req, res) => {
  const sql = `SELECT * FROM ${constants.CLASS_NAME_TABLE} WHERE id != ? AND name = ? AND group_id = ?`;
  
  db.query(sql, [req.params.id, req.body.name, req.body.group_id], (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(401).json({
        message: "Failed",
        err,
      });
    }

    if (rows.length > 0) {
      console.log(rows);
      return res.status(401).json({
        message: "Already Exists",
      });
    } else {
      // Construct the final UPDATE query string
      const query = `UPDATE ${constants.CLASS_NAME_TABLE} SET name = ? , group_id = ? WHERE id = ?`;

      // Execute the query
      db.query(query, [req.body.name,req.body.group_id,req.params.id], (err, result) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }

        // Check if any row was updated
        if (result.affectedRows === 0) {
          return res.status(404).json({ message: "Item not found" });
        }

        // Return a success response
        res.status(200).json({
          message: "Subject updated successfully",
          data: result.affectedRows,
        });
      });
    }
  });
};

//delete
exports.deleteClass = (req, res) => {
  const id = req.params.id; // Get the ID from the request parameters

  // SQL query to delete the record from the database
  const sql = `DELETE FROM ${constants.CLASS_NAME_TABLE} WHERE id = ?`;

  // Execute the SQL query
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error('Error deleting User:', err);
      return res.status(500).json({ message: 'Failed to delete item', error: err });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Item not found' });
    }

    // If the record is deleted successfully
    return res.status(200).json({ message: 'Item deleted successfully' });
  });
};
var parseRelationalDataToJson = (rows) => {
  // Format the results as JSON objects
  rows.forEach((element) => {
  
    element["group_info"] = element['group_id']!=null?JSON.parse(element.group_info):{};
  
  });
  return rows;
};