const express = require("express");
const configs = require("../config/config.json");
const constants = require("../utils/constants");
const statusCode = require("../utils/status_code");
const db = require("../config/mysqldb");


exports.getAllDurations = (req, res) => {
  const sql = `SELECT * FROM ${constants.DURATION_TABLE_NAME} ORDER BY priority ASC`;

  db.query(sql, (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(statusCode.STATUS_BAD_REQUEST).json({
        message: "Failed",
        error: err,
      });
    }
    res.status(statusCode.STATUS_OK).json({
      message: "Success",
      data: rows,
    });
  });
};
