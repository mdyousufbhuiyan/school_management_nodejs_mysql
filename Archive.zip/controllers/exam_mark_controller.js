const express = require("express");
const configs = require("../config/config.json");
const constants = require("../utils/constants");

const db = require("../config/mysqldb");
const statusCode = require("../utils/status_code");
var tName = constants.EXAM_MARKS_TABLE_NAME;
var tObj = "em";
var ayObj = "academicYear";

exports.addExamMark = (req, res) => {
  const sql = `SELECT * FROM ${tName} WHERE class_room_id = ? AND subject_id = ? AND exam_type_id = ?`;
  db.query(
    sql,
    [
      req.body.class_room_id,
      req.body.subject_id,
      req.body.exam_type_id,
    ],
    (err, rows, fields) => {
      if (err instanceof Error) {
        console.log(err);
        return res.status(statusCode.STATUS_BAD_REQUEST).json({
          message: "Failed",
          err,
        });
      }
      if (rows.length > 0) {
        console.log(rows);
        return res.status(statusCode.STATUS_CONFLICT).json({
          message: "Already Exists",
        });
      } else {
        db.query(
          `INSERT INTO ${tName} SET ?`,
          req.body,
          (err, rows, fields) => {
            if (err instanceof Error) {
              console.log(err);
              return res.status(statusCode.STATUS_BAD_REQUEST).json({
                message: "Failed",
                error: err,
              });
            } else {
              res.status(statusCode.STATUS_CREATED).json({
                message: "Success",
                data: rows,
              });
            }
          }
        );
      }
    }
  );
};
exports.getAllExamMark = (req, res) => {
  var conditions = "";
  var queryList = [];
  if (req.query.class_room_id != null) {
    conditions += `${tObj}.class_room_id = ?`;
    queryList.push(req.query.class_room_id);
  }

  if (req.query.subject_id != null) {
    conditions += `${
      conditions.length > 0 ? "AND" : ""
    } ${tObj}.subject_id = ?`;
    queryList.push(req.query.subject_id);
  }
  if (req.query.exam_type_id != null) {
    conditions += `${
      conditions.length > 0 ? "AND" : ""
    } ${tObj}.exam_type_id = ?`;
    queryList.push(req.query.exam_type_id);
  }

  if (req.query.teacher_id != null) {
    conditions += `${
      conditions.length > 0 ? "AND" : ""
    } ${tObj}.teacher_id = ?`;
    queryList.push(req.query.teacher_id);
  }
 if(queryList.length>0){
  const sql = `SELECT 
  ${this.selectedFields(tObj)},
  ${getRelationalQuery} WHERE ${conditions} ORDER BY ${ayObj}.name DESC`;

  db.query(sql,queryList, (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(statusCode.STATUS_BAD_REQUEST).json({
        message: "Failed",
        error: err,
      });
    }
       //  console.log(rows);
       return res.status(statusCode.STATUS_OK).json({
        message: "Success",
        data: parseRelationalDataToJson(rows),
      });

  });
 }else{
   // console.log(rows);
   return res.status(statusCode.STATUS_OK).json({
    message: "Success",
    data: [],
  });
 }
};

exports.getFilteredExamMark = (req, res) => {
  var conditions = "";
  var queryList = [];
  if (req.query.class_room_id != null) {
    conditions += `${tObj}.class_room_id = ?`;
    queryList.push(req.query.class_room_id);
  }

  if (req.query.subject_id != null) {
    conditions += `${
      conditions.length > 0 ? "AND" : ""
    } ${tObj}.subject_id = ?`;
    queryList.push(req.query.subject_id);
  }
  if (req.query.exam_type_id != null) {
    conditions += `${
      conditions.length > 0 ? "AND" : ""
    } ${tObj}.exam_type_id = ?`;
    queryList.push(req.query.exam_type_id);
  }

  if (req.query.teacher_id != null) {
    conditions += `${
      conditions.length > 0 ? "AND" : ""
    } ${tObj}.teacher_id = ?`;
    queryList.push(req.query.teacher_id);
  }
  // if (req.query.from_date != null && req.query.to_date != null) {
  //   conditions += `${
  //     conditions.length > 0 ? "AND" : ""
  //   } ${tObj}.attendance_date BETWEEN ? AND ?`;
  //   queryList.push(req.query.from_date);
  //   queryList.push(req.query.to_date);
  // }
  console.log(`........conditions........${conditions}.....${queryList}`);
  var sql;

  if (queryList.length > 0)
    sql = `SELECT 
  ${this.selectedFields(tObj)},
  ${getRelationalQuery} WHERE ${conditions} ORDER BY ${ayObj}.name DESC`;
  else
    sql = `SELECT 
  ${this.selectedFields(tObj)},
  ${getRelationalQuery} ORDER BY ${ayObj}.name DESC`;

  db.query(sql, queryList, (err, rows, fields) => {
    if (err instanceof Error) {
      console.log(err);
      return res.status(statusCode.STATUS_BAD_REQUEST).json({
        message: "Failed",
        error: err,
      });
    }
    //  console.log(rows);
    return res.status(statusCode.STATUS_OK).json({
      message: "Success",
      data: parseRelationalDataToJson(rows),
    });
  });
};

exports.updateExamMark = (req, res) => {
  console.log(`.............update.......${req.body}`);
  // Construct the final UPDATE query string
  const sql = `SELECT * FROM ${tName} WHERE id != ? AND class_room_id = ? AND subject_id = ? AND exam_type_id = ?`;

  db.query(
    sql,
    [
      req.params.id,
      req.body.class_room_id,
      req.body.subject_id,
      req.body.exam_type_id,
    ],
    (err, rows, fields) => {
      if (err instanceof Error) {
        console.log(err);
        return res.status(401).json({
          message: "Failed",
          err,
        });
      }

      if (rows.length > 0) {
        console.log(rows);
        return res.status(401).json({
          message: "Already Exists",
        });
      } else {
        const id = req.params.id; // Get the user id from the URL
        const updateData = req.body; // Get the fields to update from the request body

        // Dynamically build the SQL SET clause and the values array for the query
        let setClause = [];
        let values = [];

        // Loop through the keys of the object and build the SET part of the query
        for (let key in updateData) {
          if (
            key === "updated_at" ||
            key === "created_at"
            // ||
            // key === "academic_year_id" ||
            // key === "attendance_date"
          ) {
          } else {
            setClause.push(`${key} = ?`); // For each key in the object, add `key = ?`
            values.push(updateData[key]); // Push the value corresponding to the key
          }
        }
        // console.log(`.............setClause.......${setClause}..values....${values}`);
        // Add the user ID to the values array (for the WHERE clause)
        values.push(id);

        // Construct the final UPDATE query string
        const query = `UPDATE ${
          tName
        } SET ${setClause.join(", ")} WHERE id = ?`;
        // Execute the query
        db.query(query, values, (err, result) => {
          if (err) {
            return res.status(500).json({ error: err.message });
          }

          // Check if any row was updated
          if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Item not found" });
          }

          // Return a success response
          res.status(200).json({
            message: "Updated successfully",
            data: result.affectedRows,
          });
        });
      }
    }
  );
};

//delete
exports.deleteExamMark = (req, res) => {
  const id = req.params.id; // Get the ID from the request parameters

  // SQL query to delete the record from the database
  const sql = `DELETE FROM ${tName} WHERE id = ?`;

  // Execute the SQL query
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error("Error deleting User:", err);
      return res
        .status(statusCode.STATUS_BAD_REQUEST)
        .json({ message: "Failed to delete item", error: err });
    }

    if (result.affectedRows === 0) {
      return res
        .status(statusCode.STATUS_NOT_FOUND)
        .json({ message: "Not found" });
    }

    // If the record is deleted successfully
    return res
      .status(statusCode.STATUS_OK)
      .json({ message: "Deleted successfully" });
  });
};

var parseRelationalDataToJson = (rows) => {
  // Format the results as JSON objects
  rows.forEach((element) => {
    //  delete element.password;
    //  delete element.department_id;

    element["student_info"] =
      element.student_info != null ? JSON.parse(element.student_info) : {};
    //element["student_info"]=element.student_info != null?element.student_info.replace(/\"/g, ""):{};
    element["class_info"] =
      element.class_info != null ? JSON.parse(element.class_info) : {};
    element["group_info"] =
      element.group_id != null ? JSON.parse(element.group_info) : {};
    element["subject_info"] =
      element.subject_id != null && element.subject_id != 0
        ? JSON.parse(element.subject_info)
        : {};
    element["teacher_info"] =
      element.teacher_info != null ? JSON.parse(element.teacher_info) : {};
    element["academic_year_info"] =
      element.academic_year_info != null
        ? JSON.parse(element.academic_year_info)
        : {};
    element["exam_type_info"] =
        element.exam_type_info != null
          ? JSON.parse(element.exam_type_info)
          : {};
  });
  return rows;
};
var getRelationalQuery = `JSON_OBJECT('id', c.id,'name', c.name) AS class_info,
JSON_OBJECT('id', g.id,'name', g.name) AS group_info,
JSON_OBJECT('id', s.id,'name', s.name,'subject_code',s.subject_code) AS subject_info,
JSON_OBJECT('id', t.id,'first_name', t.first_name,'middle_name', t.middle_name,'last_name', t.last_name) AS teacher_info,
JSON_OBJECT('id', ${ayObj}.id,'name', ${ayObj}.name) AS academic_year_info,
JSON_OBJECT('id', e.id,'name', e.name) AS exam_type_info
FROM ${constants.EXAM_MARKS_TABLE_NAME} as ${tObj}
LEFT JOIN ${constants.CLASS_ROOM_TABLE_NAME} as cr ON ${tObj}.class_room_id = cr.id
LEFT JOIN ${constants.CLASS_NAME_TABLE} as c ON cr.class_id = c.id
LEFT JOIN ${constants.GROUP_NAME_TABLE_NAME} as g ON cr.group_id = g.id
LEFT JOIN ${constants.SUBJECT_NAME_TABLE} as s ON ${tObj}.subject_id = s.id
LEFT JOIN ${constants.TEACHER_TABLE} as t ON ${tObj}.teacher_id = t.id
LEFT JOIN ${constants.ACADEMIC_YEAR_TABLE_NAME} as ${ayObj} ON cr.academic_year_id = ${ayObj}.id
LEFT JOIN ${constants.EXAM_TYPE_TABLE_NAME} as e ON ${tObj}.exam_type_id = e.id
`;
//JSON_CONTAINS(att.student_ids, JSON_ARRAY(st.id))
//FIND_IN_SET(p.product_id, u.product_ids) > 0
exports.allFields = [
  "id",
  "class_room_id",
  "subject_id",
  "teacher_id",
  "exam_type_id",
  "total_mark",
  "pass_mark",
  "student_ids",
  "exam_marks",
  "created_at",
  "updated_at",
];

exports.selectedFields = (obj) => {
  var excludedField = [
    //  "password",
    // "division_id",
    // "district_id",
    // "upozila_id",
    // "created_at",
    // "updated_at",
  ];
  var selectedField = [];
  this.allFields.forEach((element) => {
    if (!excludedField.includes(element))
      selectedField.push(`${obj}.${element}`);
  });
  return selectedField;
};